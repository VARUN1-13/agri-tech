# -------------------------------------------------------------------------
# FLASK APPLICATION FOR LOCAL FOOD MARKETPLACE
# This application simulates the core functionality of a farmer-to-buyer platform.
# It uses a single HTML template (index.html, which should be in a 'templates' folder)
# and hardcoded Python data structures to represent the database for demonstration.
# -------------------------------------------------------------------------

from flask import Flask, render_template, request, redirect, url_for, session
import uuid  # For generating unique IDs
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'super-secret-key-for-marketplace'  # Required for sessions

# --- MOCK DATABASE STRUCTURE (Replace with Firestore/SQL in production) ---

# Mock data for Farmers and Products
MOCK_FARMERS = {
    "f1": {
        "id": "f1",
        "name": "Sunshine Acres Farm",
        "email": "sunshine@farm.com",
        "type": "Farmer",
        "location": "Central Valley, CA",
        "latitude": 36.7783,
        "longitude": -119.4179,
        "delivery_zone": "50 miles radius",
        "rating": 4.8,
        "bio": "Family-run farm specializing in organic heirloom vegetables and pasture-raised eggs.",
        "products": [
            {"id": "p1", "name": "Organic Heirloom Tomatoes", "price": 4.50, "unit": "lb", "inventory": 50,
             "available": True, "category": "Vegetable"},
            {"id": "p2", "name": "Fresh Pasture Eggs", "price": 6.00, "unit": "dozen", "inventory": 120,
             "available": True, "category": "Dairy"},
            {"id": "p3", "name": "Sweet Corn (Seasonal)", "price": 0.75, "unit": "ear", "inventory": 0,
             "available": False, "category": "Vegetable"},
        ],
        "reviews": [
            {"id": "r1", "buyer": "Restaurant A", "rating": 5,
             "comment": "Tomatoes are consistently the best in the region!"},
            {"id": "r2", "buyer": "Consumer B", "rating": 4, "comment": "Great eggs, but delivery was a little late."},
        ]
    },
    "f2": {
        "id": "f2",
        "name": "Riverbend Orchards",
        "email": "riverbend@farm.com",
        "type": "Farmer",
        "location": "Coastal Hills, CA",
        "latitude": 37.2711,
        "longitude": -122.0253,
        "delivery_zone": "20 miles radius",
        "rating": 4.5,
        "bio": "We grow apples, cherries, and stone fruit using sustainable practices. Seasonal only.",
        "products": [
            {"id": "p4", "name": "Honeycrisp Apples", "price": 3.00, "unit": "lb", "inventory": 200, "available": True,
             "category": "Fruit"},
            {"id": "p5", "name": "Bing Cherries", "price": 8.00, "unit": "lb", "inventory": 30, "available": True,
             "category": "Fruit"},
        ],
        "reviews": []
    }
}

MOCK_USERS = {
    "buyer1@app.com": {"id": "b1", "name": "Chef Mike", "type": "Buyer", "password": "password"},
    "sunshine@farm.com": {"id": "f1", "name": "Sunshine Acres Farm", "type": "Farmer", "password": "password"}
}

MOCK_ORDERS = []  # List to store pending orders


# --- Utility Functions ---

def get_current_user():
    """Retrieves user data from session."""
    user_id = session.get('user_id')
    user_type = session.get('user_type')
    user_email = session.get('user_email')
    
    if user_id and user_type == "Farmer":
        # user_id is guaranteed to be str if it exists in session
        return MOCK_FARMERS.get(user_id)
    if user_id and user_type == "Buyer" and user_email:
        # user_email is checked for existence before using it as a key
        return MOCK_USERS.get(user_email)
    return None


# --- Flask Routes ---

@app.route('/', methods=['GET', 'POST'])
def index():
    """Login/Homepage route."""
    if request.method == 'POST':
        # Safely retrieve email and password, they are guaranteed to be strings or None
        email = request.form.get('email')
        password = request.form.get('password')

        if not email or not password:
            return render_template('index.html', error="Email and password are required.")
            
        user = MOCK_USERS.get(email)

        if user and user['password'] == password:
            session['user_id'] = user['id']
            session['user_email'] = email
            session['user_type'] = user['type']
            return redirect(url_for('dashboard'))
        else:
            return render_template('index.html',
                                   error="Invalid credentials. Try 'sunshine@farm.com' or 'buyer1@app.com' with password 'password'.")

    # If already logged in, redirect to dashboard
    if get_current_user():
        return redirect(url_for('dashboard'))

    return render_template('index.html')


@app.route('/dashboard')
def dashboard():
    """Main dashboard (different view for Farmer/Buyer)."""
    user = get_current_user()
    if not user:
        return redirect(url_for('index'))

    # If Farmer, show inventory and orders
    if user.get('type') == 'Farmer':
        orders = [order for order in MOCK_ORDERS if order.get('farmer_id') == user.get('id')]
        return render_template('index.html', view='farmer_dashboard', user=user, farmer=user, orders=orders)

    # If Buyer, show discovery/search results
    return render_template('index.html', view='buyer_dashboard', user=user, farmers=MOCK_FARMERS.values())


@app.route('/farmer/<farmer_id>')
def farmer_profile(farmer_id):
    """View specific farmer's public profile."""
    # farmer_id from the URL path is guaranteed to be a string
    farmer = MOCK_FARMERS.get(farmer_id)
    if not farmer:
        return "Farmer not found", 404

    return render_template('index.html', view='farmer_profile', user=get_current_user(), farmer=farmer)


@app.route('/inventory', methods=['POST'])
def update_inventory():
    """Farmer tool to update product inventory."""
    user = get_current_user()
    if not user or user.get('type') != 'Farmer':
        return redirect(url_for('index'))

    product_id = request.form.get('product_id')
    inventory_str = request.form.get('inventory')

    if not product_id or not inventory_str:
        return redirect(url_for('dashboard', message="Error: Missing product ID or inventory value."))

    # Safely convert inventory value to integer
    try:
        new_inventory = int(inventory_str)
        if new_inventory < 0:
            raise ValueError
    except ValueError:
        return redirect(url_for('dashboard', message="Error: Invalid inventory value."))

    # Find the product and update it
    for product in user.get('products', []):
        if product.get('id') == product_id:
            product['inventory'] = new_inventory
            product['available'] = new_inventory > 0
            break

    return redirect(url_for('dashboard'))


@app.route('/place_order', methods=['POST'])
def place_order():
    """Buyer submits an order."""
    user = get_current_user()
    if not user or user.get('type') != 'Buyer':
        return redirect(url_for('index'))

    farmer_id = request.form.get('farmer_id')
    product_id = request.form.get('product_id')
    quantity_str = request.form.get('quantity')

    # Validate required form fields
    if not farmer_id or not product_id or not quantity_str:
        return redirect(url_for('dashboard', message="Error: Missing required order information."))

    # Safely convert quantity value to integer
    try:
        quantity = int(quantity_str)
        if quantity <= 0:
            raise ValueError
    except ValueError:
        return redirect(url_for('dashboard', message="Error: Invalid quantity specified."))

    farmer = MOCK_FARMERS.get(farmer_id)
    if not farmer:
        return "Farmer not found", 404

    # Simple logic to find the product and calculate price
    product = next((p for p in farmer['products'] if p.get('id') == product_id), None)
    
    if not product or not product.get('available') or product.get('inventory', 0) < quantity:
        return redirect(url_for('dashboard', message="Error: Product unavailable or requested quantity is too high."))

    order_id = str(uuid.uuid4())[:8]
    total_price = quantity * product['price']

    # Create the new order
    MOCK_ORDERS.append({
        "id": order_id,
        "buyer_id": user['id'],
        "buyer_name": user['name'],
        "farmer_id": farmer_id,
        "farmer_name": farmer['name'],
        "product_name": product['name'],
        "quantity": quantity,
        "unit": product['unit'],
        "price": product['price'],
        "total": total_price,
        "status": "Pending",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M")
    })

    # Deduct inventory
    product['inventory'] -= quantity
    if product['inventory'] == 0:
        product['available'] = False

    return redirect(url_for('dashboard', message="Order placed successfully! Order ID: " + order_id))


@app.route('/logout')
def logout():
    """Clears the user session."""
    session.clear()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
